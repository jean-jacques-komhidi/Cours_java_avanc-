package ucao.mig1.service;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import ucao.mig1.model.Filiere;
import ucao.mig1.util.HibernateUtil;

import java.util.List;
import java.util.Scanner;

public class FiliereService {
    Session session;
    public FiliereService(){
        // création de l'objet session permettant de travailler avec la base de donnée
        session = HibernateUtil.getSessionFactory().openSession();
    }
    public Filiere save(Filiere filiere) throws Exception {
        try {
            // Demarrer la transaction
            session.beginTransaction();
            // Enregister la filière dans la base de donnée
            session.save(filiere);
            // valider la transaction
            session.getTransaction().commit();
            return filiere;
        }
        catch (HibernateException e) {
            // Annuler la transaction c'est a dire annuler les actions qu'on vient de faire dans la BD
            session.getTransaction().rollback();
            throw new Exception(e);
        }
    }
    public Filiere findByLibelle(String libelle){
        try {
            return session.createQuery("SELECT f FROM Filiere f WHERE f.libelle = :libelle", Filiere.class)
                    .setParameter("libelle", libelle).getSingleResult();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public List<Filiere> findAll(){
        try {
            return session.createQuery("SELECT f FROM Filiere f", Filiere.class).list();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}

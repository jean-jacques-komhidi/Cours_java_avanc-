package ucao.mig1.util;

import jakarta.persistence.Entity;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.reflections.Reflections;
import ucao.mig1.model.Classe;
import ucao.mig1.model.Etudiant;
import ucao.mig1.model.Filiere;
import ucao.mig1.model.Inscription;

import java.util.Set;


public class HibernateUtil {
    private static SessionFactory sessionFactory;

    static {
        try {
            // Crée une Configuration à partir du fichier hibernate.cfg.xml
            Configuration configuration = new Configuration().configure();
            Reflections reflections = new Reflections("ucao");
            Set<Class<?>> entities = reflections.getTypesAnnotatedWith(Entity.class);
            for (Class<?> entity : entities){
                configuration.addAnnotatedClass(entity);
            }
            // Construit la SessionFactory
            sessionFactory = configuration.buildSessionFactory();
        } catch (Throwable ex) {
            System.err.println("Échec de la création de la SessionFactory." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }


    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void shutdown() {
        getSessionFactory().close();
    }
}

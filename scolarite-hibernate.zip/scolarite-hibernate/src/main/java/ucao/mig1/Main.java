package ucao.mig1;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import ucao.mig1.model.Filiere;
import ucao.mig1.service.FiliereService;
import ucao.mig1.util.HibernateUtil;

import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String continuer;
        do {
            System.out.println("1 - Ajouter une filière");
            System.out.println("2 - Modifier une filière");
            System.out.println("3 - Lister toutes les filières");
            System.out.println("4 - Supprimer une filière");
            System.out.println("5 - Rechercher une filière par son ID");
            System.out.println("6 - Rechercher une filière par son Libelle");
            System.out.println("7 - Quitter ");
            int choix;
            do {
                System.out.print("Entrer votre choix : ");
                 choix = sc.nextInt();
                 if (choix < 1 || choix > 7){
                     System.out.println("choix inconnu !!!");
                 }
            } while (choix < 1 || choix > 7);
            FiliereService filiereService = new FiliereService();
            switch (choix){
                case 1 :
                    try {
                        System.out.println("Saisir le nom de la filière");
                        sc.nextLine();
                        String libelle = sc.nextLine();

                        // creation de l'objet filière
                        Filiere filiere = new Filiere();
                        // Attribution du libelle saisi au clavier au libelle de la filière
                        filiere.setLibelle(libelle);
                        filiereService.save(filiere);
                        System.out.println("ok");
                    }
                    catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 2:
                    String libelle = "";
                    try {
                        System.out.println("Saisir le nom de la filière a modifier");
                        sc.nextLine();
                        libelle = sc.nextLine();
                        // creation de l'objet filière
                        Filiere filiere = filiereService.findByLibelle(libelle);
                        if (filiere != null){
                            System.out.println("Saisir le nouveau nom de la filière");
                            //sc.nextLine();
                            libelle = sc.nextLine();
                            filiere.setLibelle(libelle);
                            filiereService.save(filiere);
                            System.out.println("Filière modifier");
                        }
                    }
                    catch (Exception e) {
                        System.out.println("Filiere ["+libelle+"] introuvable");
                    }
                    break;
                case 3:
                    filiereService.findAll().forEach(filiere -> System.out.println(filiere) );
                    break;
                case 4:

                    break;
                case 5:

                    break;
                case 6:

                    break;
                case 7:

                    return;
            }
            //sc.nextLine();
            System.out.println("Voulez vous continuer (o ou O pour continuer, autre pour quitter)");
            continuer = sc.nextLine();
        } while (continuer.equals("o") || continuer.equals("O"));


    }
}
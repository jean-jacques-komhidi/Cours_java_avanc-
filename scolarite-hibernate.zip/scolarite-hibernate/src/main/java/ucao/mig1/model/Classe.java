package ucao.mig1.model;

import jakarta.persistence.*;

import java.util.Set;

@Entity
public class Classe {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(length = 10)
    private String code;
    @Column(length = 150)
    private String libelle;
    private int fraisInscription;
    private int mensualite;
    private int autreFrais;
    @ManyToOne(fetch = FetchType.EAGER)
    private Filiere filiere;
    @OneToMany(mappedBy = "classe")
    private Set<Inscription> inscriptions;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public int getFraisInscription() {
        return fraisInscription;
    }

    public void setFraisInscription(int fraisInscription) {
        this.fraisInscription = fraisInscription;
    }

    public int getMensualite() {
        return mensualite;
    }

    public void setMensualite(int mensualite) {
        this.mensualite = mensualite;
    }

    public int getAutreFrais() {
        return autreFrais;
    }

    public void setAutreFrais(int autreFrais) {
        this.autreFrais = autreFrais;
    }

    public Filiere getFiliere() {
        return filiere;
    }

    public void setFiliere(Filiere filiere) {
        this.filiere = filiere;
    }
}